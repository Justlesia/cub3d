Study project for 21 School (42cursus), 2020.

C programming can be very tedious when one doesn’t have access to those highly useful
standard functions. This project gives you the opportunity to re-write those functions,
understand them, and learn to use them.
